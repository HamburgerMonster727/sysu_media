from nltk import word_tokenize
from math import sqrt
import sys
import random
import PySide2
import os
dirname = os.path.dirname(PySide2.__file__)
plugin_path = os.path.join(dirname, 'plugins', 'platforms')
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = plugin_path
from PySide2.QtWidgets import QApplication, QMainWindow, QPushButton, QPlainTextEdit, QMessageBox

class firstWindow():
    def __init__(self):
        #定义窗口对象
        self.window = QMainWindow() 
        self.window.resize(500, 350)  
        self.window.setWindowTitle('统计句子对相似度')

        #句子A输入文本框
        self.textEdit1 = QPlainTextEdit(self.window)
        self.textEdit1.setPlaceholderText('请输入句子A') 
        self.textEdit1.move(0, 10) 
        self.textEdit1.resize(500, 100) 

        #句子B输入文本框
        self.textEdit2 = QPlainTextEdit(self.window) 
        self.textEdit2.setPlaceholderText('请输入句子B') 
        self.textEdit2.move(0, 150)
        self.textEdit2.resize(500, 100) 
        
        #计算按钮
        self.button = QPushButton('计算相似度', self.window) 
        self.button.move(200, 300)
        self.button.clicked.connect(self.handleCal) #按钮对象被点击时调用函数
        self.button.show() 

    def handleCal(self):
        #对句子进行分词
        sentense1 = self.textEdit1.toPlainText()
        sentense2 = self.textEdit2.toPlainText()
        sentenses = [sentense1, sentense2]
        texts = [[word for word in word_tokenize(sentense)] for sentense in sentenses]

        #根据句子分词，对句子建立语料库
        word = []
        for text in texts:
            word += text
        dictionary = set(word)
        dictionary_vector = dict(zip(dictionary, range(len(dictionary))))

        #根据语料库，对句子建立向量表示
        def vector(text, dictionary_vector):
            vec = []
            for key in dictionary_vector.keys():
                if key in text:
                    vec.append((dictionary_vector[key], text.count(key)))
                else:
                    vec.append((dictionary_vector[key], 0))
            vec = sorted(vec, key= lambda x: x[0])
            return vec
        vector1 = vector(texts[0], dictionary_vector)
        vector2 = vector(texts[1], dictionary_vector)

        #根据句子的向量表示，计算两个向量的余弦值来作为相似度
        def similarity(vector1, vector2):
            inner_product = 0
            length_vector1 = 0
            length_vector2 = 0
            for point1, point2 in zip(vector1, vector2):
                inner_product += point1[1]*point2[1]
                length_vector1 += point1[1]**2
                length_vector2 += point2[1]**2
            return (inner_product/sqrt(length_vector1*length_vector2))
        similar = similarity(vector1, vector2)

        #弹出窗口显示计算结果
        QMessageBox.about(self.window, 
                        '计算结果',
                        f'''相似度为：\n{similar}'''
                        )

app = QApplication([]) 
first = firstWindow()
first.window.show()
app.exec_()